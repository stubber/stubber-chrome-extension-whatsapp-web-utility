# Chrome Web Store Console

[Click here](https://chrome.google.com/webstore/devconsole/ad6dd312-2c4e-4767-a172-4d31c15c2f0c)

# Updating

1. Update the version in `manifest.json`
2.
